<#
.DISCLAIMER
    MIT License - Copyright (c) Microsoft Corporation. All rights reserved.
    Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
    FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
    IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE
.DESCRIPTION
    Activate Azure with Hybrid Cloud - Main Track - FileName: configdc1.ps1
    This script configures the secondary disk, creates a new Domain, Install DNS, configures the domain controller VM
.NOTES
    AUTHOR(S): Microsoft Enterprise Services
    KEYWORDS: Azure Deploy, PoC, Deployment
#>
configuration configdc1
{
   param 
   ( 
        [string]$domainName,
        [int]$DiskNumber,
		[string]$DriveLetter,
        [System.Management.Automation.PSCredential]$Credential
    )
    Import-DscResource -ModuleName xActiveDirectory, cDisk, xDisk, xNetworking, PSDesiredStateConfiguration, xComputerManagement
    [string]$netbiosDomainName = $domainName.Split(".")[0]
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${netbiosDomainName}\$($Credential.UserName)", $Credential.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {

     LocalConfigurationManager 
        {
			ConfigurationMode = 'ApplyAndAutoCorrect'
			RebootNodeIfNeeded = $true
			ActionAfterReboot = 'ContinueConfiguration'
			AllowModuleOverwrite = $true
        }

	    WindowsFeature DNS 
        { 
            Ensure = "Present"
            Name = "DNS"
        }

        Script EnableDNSDiags
	    {
      	    SetScript = { 
		        Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false }
	        DependsOn = "[WindowsFeature]DNS"
        }

	    WindowsFeature DnsTools
	    {
	        Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
	    }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
	        DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature RSAT_Role_Tools
		{
			Ensure = 'Present'
			Name   = 'RSAT-Role-Tools'
		}   

        xWaitforDisk Disk2
        {
			DiskNumber = $DiskNumber
			RetryCount = 20
			RetryIntervalSec = 30
			DependsOn = "[WindowsFeature]RSAT_Role_Tools"
        }

        cDiskNoRestart ADDataDisk
        {
            DiskNumber = $DiskNumber
			DriveLetter = $DriveLetter
	        DependsOn="[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
            DependsOn="[WindowsFeature]DNS"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        xADDomain FirstDS
        {
            DomainName = $domainName
			DomainAdministratorCredential = [System.Management.Automation.PSCredential]$DomainCreds
			SafemodeAdministratorPassword = [System.Management.Automation.PSCredential]$DomainCreds
            DatabasePath = $DriveLetter + ":\NTDS"
			LogPath = $DriveLetter + ":\NTDS"
			SysvolPath = $DriveLetter + ":\SYSVOL"
            DependsOn = @("[cDiskNoRestart]ADDataDisk", "[WindowsFeature]ADDSInstall")
        }
    }
}